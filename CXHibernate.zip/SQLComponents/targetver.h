#pragma once

// Including SDKDDKVer.h defines the highest available Windows platform.

// If you wish to build your application for a previous Windows platform, include WinSDKVer.h and
// set the _WIN32_WINNT macro to the platform you wish to support before including SDKDDKVer.h.

#include <SDKDDKVer.h>


// #ifndef WINVER                  // Specifies that the minimum required platform is Windows Vista.
// #define WINVER 0x0600           // Change this to the appropriate value to target other versions of Windows.
// #endif
// 
// #ifndef _WIN32_WINNT            // Specifies that the minimum required platform is Windows Vista.
// #define _WIN32_WINNT 0x0600     // Change this to the appropriate value to target other versions of Windows.
// #endif
// 
// #ifndef _WIN32_WINDOWS          // Specifies that the minimum required platform is Windows Vista
// #define _WIN32_WINDOWS 0x0600   // Change this to the appropriate value to target Windows Me or later.
// #endif
// 
// #ifndef _WIN32_IE               // Specifies that the minimum required platform is Internet Explorer 8.0.
// #define _WIN32_IE 0x0800        // Change this to the appropriate value to target other versions of IE.
// #endif
// 
