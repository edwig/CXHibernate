// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"
#include "afx.h"

// Headers for CppUnitTest
#include "CppUnitTest.h"

#include <SQLComponents.h>
#include <CXHibernate.h>
#include <Marlin.h>