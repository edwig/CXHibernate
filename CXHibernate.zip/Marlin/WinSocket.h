#pragma once

// Startup WSA Winsockets
bool        MarlinStartupWinsocket();
// Cleaning up the WinSocket library
void _cdecl MarlinCleanupWinsocket();
